import urllib.parse

data = "中国"
quo_data = urllib.parse.quote(data)
print(quo_data)
