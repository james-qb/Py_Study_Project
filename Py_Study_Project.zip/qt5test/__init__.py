#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/8/26 17:44
# @Author  : qiubin
# @File    : __init__.py.py
# @Software: PyCharm


import qt5test
